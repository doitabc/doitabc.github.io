#!/usr/bin/env node

require("./server.js").run.apply(null, process.argv.slice(2));
